public class Biblioteca {
    private Livro[] vetorDeLivros;
    private int contadorLivros;

    public Biblioteca(int capacidade) {
        this.vetorDeLivros = new Livro[capacidade];
        this.contadorLivros = 0;
    }
    public void adicionarLivro(Livro livro) {
        if (this.contadorLivros < this.vetorDeLivros.length) {
            this.vetorDeLivros[this.contadorLivros] = livro;
            this.contadorLivros++;
            System.out.println("Livro '" + livro.getTitulo() + "' adicionado à biblioteca.");
        } else {
            System.out.println("A biblioteca está cheia. Não é possível adicionar mais livros.");
        }
    }

    public void emprestarLivro(String titulo) {
        for (int i = 0; i < this.contadorLivros; i++) {
            if (this.vetorDeLivros[i].getTitulo().equalsIgnoreCase(titulo)) {
                this.vetorDeLivros[i].emprestar();
                return;
            }
        }
        System.out.println("Livro '" + titulo + "' não encontrado.");
    }

    public void devolverLivro(String titulo) {
        for (int i = 0; i < this.contadorLivros; i++) {
            if (this.vetorDeLivros[i].getTitulo().equalsIgnoreCase(titulo)) {
                this.vetorDeLivros[i].devolver();
                return;
            }
        }
        System.out.println("Livro '" + titulo + "' não encontrado.");
    }
    public void mostrarLivros() {
        System.out.println("\n--- Livros na Biblioteca ---");
        if (this.contadorLivros == 0) {
            System.out.println("Nenhum livro cadastrado.");
        } else {
            for (int i = 0; i < this.contadorLivros; i++) {
                this.vetorDeLivros[i].exibirInformacoes();
            }
        }
        System.out.println("----------------------------\n");
    }
}