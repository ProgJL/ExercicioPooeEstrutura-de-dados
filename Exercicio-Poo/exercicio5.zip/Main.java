public class Main {
    public static void main(String[] args) {
        Biblioteca minhaBiblioteca = new Biblioteca(5);

        // 2. Adicione pelo menos 3 livros
        Livro livro1 = new Livro("A Batalha do Apocalipse", "Eduardo Spohr");
        Livro livro2 = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien");
        Livro livro3 = new Livro("1984", "George Orwell");
        Livro livro4 = new Livro("A Revolução dos Bichos", "George Orwell");

        minhaBiblioteca.adicionarLivro(livro1);
        minhaBiblioteca.adicionarLivro(livro2);
        minhaBiblioteca.adicionarLivro(livro3);
        minhaBiblioteca.adicionarLivro(livro4);

        minhaBiblioteca.mostrarLivros();

        minhaBiblioteca.emprestarLivro("O Senhor dos Anéis");

        minhaBiblioteca.mostrarLivros();
        
        minhaBiblioteca.devolverLivro("O Senhor dos Anéis");

        minhaBiblioteca.mostrarLivros();
    }
}