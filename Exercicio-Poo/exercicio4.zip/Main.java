public class Main
{
	public static void main(String[] args) {
		Produto p1 = new Produto();
		p1.setNome("Computador");
		p1.setPreco(2000.0);
		
		String nome1 = p1.getNome();
		System.out.println("nome do produto e "+nome1);
		
		double preco1 = p1.getPreco();
		System.out.println("O preco do produto e "+preco1);
		
		
		
		
		
		Produto p2 = new Produto();
		p2.setNome("notebook");
		p2.setPreco(2500.0);
		
		nome1 = p2.getNome();
		System.out.println("nome do produto e "+nome1);
		
		preco1 = p2.getPreco();
		System.out.println("O preco do produto e "+preco1);
		
		
		
	}
}
